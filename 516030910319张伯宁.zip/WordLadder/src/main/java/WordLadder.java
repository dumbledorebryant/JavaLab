import java.util.*;
import java.io.*;

/*
 *Filename Javalab.java
 *@Author: Z.BurNIng Ingram
 *@Date: March 4th, 2018
 *
 */
class GetInput
{
    String wordOne;
    String wordTwo;

    private boolean setWord_one(BufferedReader br)throws Exception
    {
        System.out.print("Word #1 (or Enter to quit): ");
        wordOne = br.readLine();
        wordOne = wordOne.toLowerCase();
        if( wordOne.length() == 0 )
        {
            System.out.println("Have a nice day.");
            return false;
        }
        return true;
    }
    private boolean setWord_two(BufferedReader br)throws Exception
    {
        System.out.print("Word #2 (or Enter to quit): ");
        wordTwo = br.readLine();
        wordTwo = wordTwo.toLowerCase();
        if( wordTwo.length() == 0 )
        {
            System.out.println("Have a nice day.");
            return false;
        }
        return true;
    }
    public boolean readWords(BufferedReader br)throws Exception
    {
        if( !setWord_one(br) )
            return false;
        if( !setWord_two(br) )
            return  false;
        return true;
    }
}

class Judge extends GetInput
{
    public boolean judge_length()
    {
        if( wordOne.length() != wordTwo.length() )
        {
            System.out.println("The two words must be the same length.");
            return false;
        }
        return true;
    }
    public boolean judge_equality()
    {
        if( wordOne.equals(wordTwo) )
        {
            System.out.println("The two words must be different.");
            return false;
        }
        return true;
    }
    public boolean judge_containing(Set<String> dict)
    {
        if( !dict.contains(wordOne) || !dict.contains(wordTwo))
        {
            System.out.println("The two words must be found in the dictionary.");
            return false;
        }
        return true;
    }
}

class Reader
{
    void read(Set<String> dict, BufferedReader br)throws Exception
    {
        String fileName;
        while( true )
        {
            System.out.print("Dictionary file name? ");
            fileName = br.readLine();
            if( fileName.length() != 0)
            {
                File findFile = new File(fileName);
                if( findFile.exists() )
                {
                    BufferedReader fileReader = new BufferedReader(new FileReader(findFile));
                    String dict_word = fileReader.readLine();
                    while(dict_word != null)
                    {
                        dict.add(dict_word);
                        dict_word = fileReader.readLine();
                    }
                    break;
                }
                else{ System.out.println("Unable to open that file.  Try again."); }
            }
        }
    }
}

public class WordLadder
{
    public static void main(String []args) throws Exception
    {
        Set<String> dict = new HashSet<String>();
        BufferedReader br = new BufferedReader( new InputStreamReader(System.in) );
        Judge wordPairs = new Judge();

        Reader fileReader = new Reader();
        fileReader.read(dict,br);

        while( true )
        {
            if( !wordPairs.readWords(br) )
            {
                break;
            }
            else if( !wordPairs.judge_length() ) {}
            else if( !wordPairs.judge_equality() ) {}
            else if( !wordPairs.judge_containing(dict) ) {}

            else {
                String word1;
                String word2;
                Queue<Stack<String>> wordWay = new LinkedList<Stack<String>>();
                Set<String> appeared = new HashSet<String>();
                Stack<String> head_ladder = new Stack<String>();

                word1 = wordPairs.wordOne;
                word2 = wordPairs.wordTwo;

                int length = word1.length();

                head_ladder.push(word1);
                wordWay.offer(head_ladder);
                appeared.add(word1);

                boolean flag = true;
                while( !wordWay.isEmpty() && flag ){

                    Stack<String> single_ladder = wordWay.poll();
                    String word = single_ladder.peek();

                    boolean flagA = true;
                    for(int i = 0; i < length && flagA; i++)
                    {
                        char[] temp = word.toCharArray();
                        boolean flagB = true;
                        for(char j = 'a'; j <= 'z' && flagB; j++)
                        {
                            temp[i] = j;
                            String neighbor = new String(temp);

                            if(dict.contains(neighbor) && !appeared.contains(neighbor))
                            {
                                if(neighbor.equals(word2))
                                {
                                    System.out.println("A ladder from "+ word2 + " back to " + word1 + ":");
                                    System.out.print(neighbor);
                                    while( !single_ladder.empty() )
                                    {
                                        System.out.print(" " + single_ladder.pop());
                                    }
                                    System.out.println();

                                    appeared.clear();
                                    flag = false;
                                    flagA = false;
                                    flagB = false;
                                }
                                else
                                {
                                    Stack<String> newCopy = new Stack<String>();
                                    for ( String step : single_ladder)
                                    {
                                        newCopy.push(step);
                                    }
                                    newCopy.push(neighbor);
                                    wordWay.offer(newCopy);
                                    appeared.add(neighbor);
                                }
                            }
                        }
                    }
                }
                if( flag )
                {
                    System.out.println("No word ladder found from " + word1 + " back to " + word2 + ".");
                }
                wordWay.clear();
            }
        }
    }
}
