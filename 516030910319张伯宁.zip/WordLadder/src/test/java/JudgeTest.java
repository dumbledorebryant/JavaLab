import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class JudgeTest {
    Judge judge_pairs = new Judge();
    @Test
    public void judge_length()
    {
        judge_pairs.wordOne = "code";
        judge_pairs.wordTwo = "data";
        assertTrue(judge_pairs.judge_length());
        System.out.println("Length_Test: PASSED!");
    }

    @Test
    public void judge_equality()
    {
        judge_pairs.wordOne = "ingram";
        judge_pairs.wordTwo = "source";
        assertTrue( judge_pairs.judge_equality() );
        System.out.println("Equality_Test: PASSED!");
    }
}